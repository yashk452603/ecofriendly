# 🌱 EcoVision - System Architecture

## Overview

EcoVision is a complete AI-powered air quality prediction system consisting of multiple integrated components.

---

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      ECOVISION SYSTEM                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐      ┌──────────────┐      ┌──────────────┐  │
│  │   USER      │      │   DATASET    │      │  ML MODELS   │  │
│  │  INTERFACE  │◄─────┤  GENERATOR   │─────►│   TRAINER    │  │
│  │ (Dashboard) │      │              │      │              │  │
│  └──────┬──────┘      └──────────────┘      └──────┬───────┘  │
│         │                                            │          │
│         │                                            │          │
│         │              ┌──────────────┐             │          │
│         └─────────────►│   FLASK API  │◄────────────┘          │
│                        │   (Backend)  │                        │
│                        └──────┬───────┘                        │
│                               │                                │
│                        ┌──────▼───────┐                        │
│                        │  TRAINED     │                        │
│                        │  MODELS      │                        │
│                        │  - Regression│                        │
│                        │  - Classifier│                        │
│                        │  - Scaler    │                        │
│                        └──────────────┘                        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Flow

### 1. Data Generation Phase

```
generate_demo_data.py
        │
        ▼
 Creates 1000 samples
        │
        ▼
 air_quality.csv
 (8 features + AQI)
```

### 2. Model Training Phase

```
air_quality.csv
        │
        ▼
  train_model.py
        │
        ├──► Data Preprocessing
        │    - Remove outliers
        │    - Handle missing values
        │    - Create categories
        │
        ├──► Feature Scaling
        │    - StandardScaler
        │
        ├──► Train Models
        │    - Decision Tree Regressor
        │    - Decision Tree Classifier
        │
        ├──► Evaluate
        │    - Calculate metrics
        │    - Feature importance
        │
        └──► Save Models
             - model_reg.pkl
             - model_class.pkl
             - scaler.pkl
```

### 3. API Server Phase

```
Flask API (app.py)
        │
        ├──► Load Models
        │    - model_reg.pkl
        │    - model_class.pkl
        │    - scaler.pkl
        │
        ├──► Endpoints
        │    - GET /
        │    - GET /health
        │    - POST /predict
        │
        └──► Process Requests
             - Validate input
             - Scale features
             - Make predictions
             - Return results
```

### 4. Dashboard Phase

```
Streamlit Dashboard (frontend/app.py)
        │
        ├──► User Input
        │    - Adjust sliders
        │    - Upload CSV
        │
        ├──► API Communication
        │    - POST to /predict
        │    - Receive results
        │
        ├──► Visualization
        │    - AQI Gauge
        │    - Pollutant Charts
        │    - Trend Analysis
        │
        └──► Display Results
             - AQI Value
             - Category
             - Health Advisory
```

---

## Data Flow Diagram

### Single Prediction Flow

```
User Input (Dashboard)
        │
        ▼
┌───────────────────┐
│ PM2.5 = 85.0      │
│ PM10  = 120.0     │
│ CO    = 1.2       │
│ NO2   = 45.0      │
│ SO2   = 30.0      │
│ O3    = 70.0      │
│ Temp  = 28.0      │
│ Humid = 65.0      │
└─────────┬─────────┘
          │
          ▼
    POST /predict
          │
          ▼
  ┌───────────────┐
  │  Flask API    │
  │  Validation   │
  └───────┬───────┘
          │
          ▼
  ┌───────────────┐
  │  Scale        │
  │  Features     │
  └───────┬───────┘
          │
          ▼
  ┌───────────────┐
  │  Regression   │
  │  Model        │
  │  (AQI Value)  │
  └───────┬───────┘
          │
          ▼
  ┌───────────────┐
  │Classification │
  │  Model        │
  │  (Category)   │
  └───────┬───────┘
          │
          ▼
    JSON Response
          │
          ▼
┌─────────────────────┐
│ AQI: 128.45         │
│ Category: Poor      │
│ Health Impact: ...  │
│ Recommendation: ... │
└──────────┬──────────┘
           │
           ▼
    Display Results
           │
           ▼
    Visualizations
```

---

## Technology Stack

### Backend

```
┌────────────────────────────┐
│   Flask 3.0.0              │
│   - REST API Framework     │
│   - CORS Support           │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│   scikit-learn 1.3.2       │
│   - Decision Trees         │
│   - StandardScaler         │
│   - Train/Test Split       │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│   pandas 2.1.4             │
│   - Data Processing        │
│   - CSV Handling           │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│   numpy 1.26.2             │
│   - Numerical Operations   │
│   - Array Processing       │
└────────────────────────────┘
```

### Frontend

```
┌────────────────────────────┐
│   Streamlit 1.29.0         │
│   - Web Framework          │
│   - Interactive UI         │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│   Plotly 5.18.0            │
│   - Interactive Charts     │
│   - Gauge, Bar, Line       │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│   Requests 2.31.0          │
│   - HTTP Client            │
│   - API Communication      │
└────────────────────────────┘
```

---

## Machine Learning Pipeline

### Training Pipeline

```
Raw Data
   │
   ▼
┌─────────────────┐
│ Load CSV        │
│ Check Missing   │
│ Validate Schema │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Remove Outliers │
│ IQR Method      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Create Features │
│ X: 8 features   │
│ y_reg: AQI      │
│ y_class: Cat    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Train/Test      │
│ Split 80/20     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Scale Features  │
│ StandardScaler  │
└────────┬────────┘
         │
         ├──────────────┐
         │              │
         ▼              ▼
┌────────────┐  ┌──────────────┐
│ Regression │  │Classification│
│   Model    │  │    Model     │
└─────┬──────┘  └──────┬───────┘
      │                │
      ▼                ▼
┌────────────┐  ┌──────────────┐
│ Evaluate   │  │  Evaluate    │
│ MAE, RMSE  │  │  Accuracy    │
│ R² Score   │  │  Precision   │
└─────┬──────┘  └──────┬───────┘
      │                │
      └────────┬───────┘
               │
               ▼
      ┌────────────────┐
      │  Save Models   │
      │  - model_reg   │
      │  - model_class │
      │  - scaler      │
      └────────────────┘
```

### Prediction Pipeline

```
Input Features (8)
        │
        ▼
┌─────────────────┐
│  Validate Input │
│  - Check types  │
│  - Check ranges │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Load Models    │
│  - Regression   │
│  - Classifier   │
│  - Scaler       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Scale Features │
│  Using scaler   │
└────────┬────────┘
         │
         ├──────────────┐
         │              │
         ▼              ▼
┌────────────┐  ┌──────────────┐
│ Regression │  │Classification│
│ Predict    │  │   Predict    │
│ AQI Value  │  │   Category   │
└─────┬──────┘  └──────┬───────┘
      │                │
      └────────┬───────┘
               │
               ▼
      ┌────────────────┐
      │  Add Advisory  │
      │  - Health Info │
      │  - Recommend   │
      └────────┬───────┘
               │
               ▼
         Return JSON
```

---

## File Structure

```
ecovision/
│
├── 📊 DATA LAYER
│   └── dataset/
│       ├── generate_demo_data.py
│       └── air_quality.csv (generated)
│
├── 🤖 MODEL LAYER
│   └── backend/model/
│       ├── train_model.py
│       ├── model_reg.pkl (generated)
│       ├── model_class.pkl (generated)
│       ├── scaler.pkl (generated)
│       ├── model_evaluation.txt (generated)
│       └── feature_importance.png (generated)
│
├── 🌐 API LAYER
│   └── backend/
│       └── app.py
│
├── 🎨 PRESENTATION LAYER
│   └── frontend/
│       └── app.py
│
├── 🛠️ UTILITIES
│   ├── test_api.py
│   ├── setup.bat
│   ├── start_api.bat
│   └── start_dashboard.bat
│
├── 📖 DOCUMENTATION
│   ├── README.md
│   ├── GETTING_STARTED.md
│   ├── INSTALLATION.txt
│   ├── QUICKSTART.txt
│   ├── PROJECT_SUMMARY.txt
│   └── ARCHITECTURE.md (this file)
│
└── 📝 CONFIGURATION
    ├── requirements.txt
    └── sample_batch.csv
```

---

## API Architecture

### Request/Response Flow

```
Client
  │
  │ HTTP Request
  ▼
┌─────────────────┐
│  Flask App      │
│  (app.py)       │
└────────┬────────┘
         │
         ├──► GET /
         │    └─► Returns API info
         │
         ├──► GET /health
         │    └─► Returns health status
         │
         └──► POST /predict
              │
              ├──► Validate request
              │    - Check JSON
              │    - Check fields
              │    - Check types
              │    - Check ranges
              │
              ├──► Load models
              │    - Regression
              │    - Classification
              │    - Scaler
              │
              ├──► Process
              │    - Scale features
              │    - Predict AQI
              │    - Predict category
              │    - Get advisory
              │
              └──► Return response
                   - AQI value
                   - Category
                   - Health info
                   - Timestamp
```

---

## Dashboard Architecture

### Component Hierarchy

```
Streamlit App
  │
  ├──► Page Config
  │    - Title
  │    - Icon
  │    - Layout
  │
  ├──► Custom CSS
  │    - Styling
  │    - Theming
  │
  ├──► API Health Check
  │    - Connection status
  │    - Model status
  │
  ├──► Sidebar
  │    │
  │    ├──► Input Controls
  │    │    - 8 Sliders
  │    │    - Tooltips
  │    │    - Validation
  │    │
  │    ├──► Predict Button
  │    │
  │    └──► Batch Upload
  │         - File uploader
  │         - Process button
  │         - Download button
  │
  └──► Main Area
       │
       ├──► Metrics Row
       │    - AQI Value
       │    - Category
       │    - Confidence
       │
       ├──► Visualizations
       │    │
       │    ├──► AQI Gauge
       │    ├──► Pollutant Chart
       │    ├──► Health Advisory
       │    └──► Trend Chart
       │
       └──► Batch Results
            - Data table
            - Download link
```

---

## Deployment Architecture

### Local Deployment (Current)

```
┌─────────────────────────────────────────┐
│         Local Machine                   │
│                                         │
│  ┌─────────────┐    ┌──────────────┐   │
│  │  Terminal 1 │    │  Terminal 2  │   │
│  │             │    │              │   │
│  │  Flask API  │    │  Streamlit   │   │
│  │  Port 5000  │◄───┤  Port 8501   │   │
│  └─────────────┘    └──────────────┘   │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │  Trained Models                  │  │
│  │  - model_reg.pkl                 │  │
│  │  - model_class.pkl               │  │
│  │  - scaler.pkl                    │  │
│  └──────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

### Production Deployment (Optional)

```
┌─────────────────────────────────────────────────┐
│              Cloud Platform                     │
│  (AWS / Azure / GCP)                            │
│                                                 │
│  ┌──────────────────────────────────────────┐  │
│  │  Load Balancer                           │  │
│  └────────────┬─────────────────────────────┘  │
│               │                                 │
│       ┌───────┴────────┐                       │
│       │                │                       │
│  ┌────▼────┐     ┌────▼────┐                  │
│  │ Flask   │     │ Flask   │                  │
│  │ API     │     │ API     │                  │
│  │Instance │     │Instance │                  │
│  └────┬────┘     └────┬────┘                  │
│       │               │                        │
│       └───────┬───────┘                        │
│               │                                │
│     ┌─────────▼──────────┐                    │
│     │  Model Storage     │                    │
│     │  (S3 / Blob)       │                    │
│     └────────────────────┘                    │
│                                                │
│  ┌──────────────────────────────────────────┐ │
│  │  Streamlit Dashboard                     │ │
│  │  (Streamlit Cloud / Custom)              │ │
│  └──────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

---

## Security Architecture

### Input Validation

```
User Input
    │
    ▼
┌────────────────┐
│  Type Check    │
│  - All numeric │
└────────┬───────┘
         │
         ▼
┌────────────────┐
│  Range Check   │
│  - No negative │
│  - Within max  │
└────────┬───────┘
         │
         ▼
┌────────────────┐
│  Field Check   │
│  - All present │
│  - Correct key │
└────────┬───────┘
         │
         ▼
    Process ✓
```

---

## Performance Characteristics

### Throughput

- **API Response Time**: < 100ms
- **Model Inference**: < 50ms
- **Dashboard Load**: < 2 seconds
- **Batch Processing**: ~100 records/second

### Scalability

- **Concurrent Users**: 100+ (local)
- **Batch Size**: Unlimited
- **Data Storage**: Lightweight (< 10MB models)

---

## Future Enhancements

### Planned Architecture Updates

```
Current Architecture
        │
        ▼
┌────────────────────┐
│  Add Database      │
│  - PostgreSQL      │
│  - Historical Data │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│  Add Caching       │
│  - Redis           │
│  - Faster Response │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│  Add Queue         │
│  - Celery          │
│  - Async Process   │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│  Add Monitoring    │
│  - Prometheus      │
│  - Grafana         │
└────────────────────┘
```

---

**Built with ❤️ for cleaner air and healthier communities**

🌱 **EcoVision** - Empowering environmental awareness through AI
