import requests
import json

# API endpoint
API_URL = "http://127.0.0.1:5000/predict"

# Test data
test_data = {
    "PM2.5": 85.0,
    "PM10": 120.0,
    "CO": 1.2,
    "NO2": 45.0,
    "SO2": 30.0,
    "O3": 70.0,
    "Temperature": 28.0,
    "Humidity": 65.0
}

print("=" * 60)
print("🧪 Testing EcoVision API")
print("=" * 60)

print("\n📤 Sending request to:", API_URL)
print("\n📊 Test data:")
print(json.dumps(test_data, indent=2))

try:
    response = requests.post(API_URL, json=test_data)
    
    print("\n📥 Response status code:", response.status_code)
    
    if response.status_code == 200:
        result = response.json()
        print("\n✅ Prediction successful!")
        print("\n📋 Results:")
        print(json.dumps(result, indent=2))
        
        print("\n" + "=" * 60)
        print(f"🌱 AQI: {result['AQI']}")
        print(f"🎯 Category: {result['Category']}")
        print(f"💡 Health Impact: {result['health_impact']}")
        print("=" * 60)
    else:
        print("\n❌ Error:", response.json())

except requests.exceptions.ConnectionError:
    print("\n❌ Connection Error: Flask API is not running!")
    print("💡 Please start the API first: python backend/app.py")
except Exception as e:
    print(f"\n❌ Error: {str(e)}")
