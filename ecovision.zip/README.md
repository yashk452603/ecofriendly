# 🌱 EcoVision - AI-Powered Air Quality & Pollution Risk Prediction

Complete AI-powered system for predicting Air Quality Index (AQI) and pollution risk categories using dual machine learning models.

## 🎯 Features

- **Dual ML Models**: Regression (AQI prediction) + Classification (Risk categorization)
- **Interactive Dashboard**: Real-time predictions with beautiful visualizations
- **REST API**: Flask-based API for easy integration
- **Batch Processing**: Upload CSV files for bulk predictions
- **Health Advisories**: Personalized recommendations based on air quality
- **Real-time Analytics**: Pollutant level comparisons and trend analysis

## 📊 System Architecture

```
ecovision/
├── backend/
│   ├── model/
│   │   ├── train_model.py      # ML training pipeline
│   │   ├── model_reg.pkl       # Regression model (generated)
│   │   ├── model_class.pkl     # Classification model (generated)
│   │   └── scaler.pkl          # Feature scaler (generated)
│   └── app.py                  # Flask API server
├── frontend/
│   └── app.py                  # Streamlit dashboard
├── dataset/
│   ├── generate_demo_data.py   # Dataset generator
│   └── air_quality.csv         # Training data (generated)
├── requirements.txt            # Python dependencies
├── setup.bat                   # Setup script (Windows)
├── start_api.bat              # API launcher (Windows)
├── start_dashboard.bat        # Dashboard launcher (Windows)
└── test_api.py                # API testing script
```

## 🚀 Quick Start Guide

### Step 1: Environment Setup

```bash
# Run setup script (installs all dependencies)
setup.bat

# Or manually:
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### Step 2: Generate Dataset

```bash
cd dataset
python generate_demo_data.py
```

**Output**: `air_quality.csv` with 1000 samples

### Step 3: Train Models

```bash
cd backend\model
python train_model.py
```

**Generated files**:
- `model_reg.pkl` - Regression model
- `model_class.pkl` - Classification model
- `scaler.pkl` - Feature scaler
- `model_evaluation.txt` - Performance metrics
- `feature_importance.png` - Feature importance plot

### Step 4: Start API Server

```bash
# Terminal 1
start_api.bat

# Or manually:
cd backend
python app.py
```

API will be available at: `http://127.0.0.1:5000`

### Step 5: Launch Dashboard

```bash
# Terminal 2
start_dashboard.bat

# Or manually:
streamlit run frontend\app.py
```

Dashboard will open automatically in your browser at: `http://localhost:8501`

## 🔧 API Documentation

### Endpoints

#### 1. Home
```http
GET /
```

**Response**:
```json
{
  "message": "🌿 EcoVision API Running",
  "version": "1.0",
  "status": "active",
  "endpoints": {...}
}
```

#### 2. Health Check
```http
GET /health
```

**Response**:
```json
{
  "status": "healthy",
  "models_loaded": true,
  "timestamp": "2025-11-05T10:30:00"
}
```

#### 3. Predict AQI
```http
POST /predict
Content-Type: application/json
```

**Request Body**:
```json
{
  "PM2.5": 85.0,
  "PM10": 120.0,
  "CO": 1.2,
  "NO2": 45.0,
  "SO2": 30.0,
  "O3": 70.0,
  "Temperature": 28.0,
  "Humidity": 65.0
}
```

**Response**:
```json
{
  "AQI": 128.45,
  "Category": "Poor",
  "health_impact": "Members of sensitive groups may experience health effects...",
  "recommendation": "People with respiratory conditions should limit outdoor activities...",
  "icon": "😷",
  "timestamp": "2025-11-05T10:30:00",
  "input_data": {...}
}
```

### Testing API

```bash
python test_api.py
```

Or using cURL:
```bash
curl -X POST http://127.0.0.1:5000/predict ^
  -H "Content-Type: application/json" ^
  -d "{\"PM2.5\": 85.0, \"PM10\": 120.0, \"CO\": 1.2, \"NO2\": 45.0, \"SO2\": 30.0, \"O3\": 70.0, \"Temperature\": 28.0, \"Humidity\": 65.0}"
```

## 📊 Model Performance

### Regression Model (AQI Prediction)
- **Algorithm**: Decision Tree Regressor
- **Expected R² Score**: ~0.85-0.90
- **Expected RMSE**: ~12-18

### Classification Model (Risk Category)
- **Algorithm**: Decision Tree Classifier
- **Expected Accuracy**: ~90-95%
- **Categories**: Good, Moderate, Poor

### Feature Importance (Top Contributors)
1. PM2.5 (Fine Particulate Matter)
2. PM10 (Coarse Particulate Matter)
3. CO (Carbon Monoxide)
4. NO₂ (Nitrogen Dioxide)

## 🎨 Dashboard Features

### Input Panel
- Interactive sliders for all 8 parameters
- Real-time input validation
- Tooltips with parameter descriptions
- Units clearly displayed

### Visualizations
1. **AQI Gauge Chart**: Color-coded gauge showing current AQI level
2. **Pollutant Bar Chart**: Current levels vs safe limits
3. **Health Advisory Card**: Personalized recommendations
4. **Weekly Trend**: 7-day simulated AQI trend

### Batch Processing
- Upload CSV files with multiple measurements
- Progress tracking
- Download results as CSV

## 📋 Input Parameters

| Parameter | Unit | Range | Description |
|-----------|------|-------|-------------|
| PM2.5 | µg/m³ | 0-200 | Fine particulate matter |
| PM10 | µg/m³ | 0-300 | Inhalable particulate matter |
| CO | mg/m³ | 0-5 | Carbon Monoxide |
| NO₂ | µg/m³ | 0-150 | Nitrogen Dioxide |
| SO₂ | µg/m³ | 0-100 | Sulfur Dioxide |
| O₃ | µg/m³ | 0-200 | Ozone |
| Temperature | °C | -10-50 | Ambient temperature |
| Humidity | % | 0-100 | Relative humidity |

## 🎯 AQI Categories

| AQI Range | Category | Color | Health Impact |
|-----------|----------|-------|---------------|
| 0-50 | Good | 🟢 Green | Air quality is satisfactory |
| 51-100 | Moderate | 🟡 Yellow | Acceptable for most people |
| 101-150 | Unhealthy for Sensitive | 🟠 Orange | Sensitive groups may be affected |
| 151-200 | Unhealthy | 🔴 Red | Everyone may experience effects |
| 201-300 | Very Unhealthy | 🟣 Purple | Health alert |
| 301+ | Hazardous | 🟤 Maroon | Emergency conditions |

## 🔬 Technology Stack

### Backend
- **Flask**: REST API framework
- **scikit-learn**: Machine learning models
- **pandas**: Data processing
- **NumPy**: Numerical computations
- **joblib**: Model persistence

### Frontend
- **Streamlit**: Interactive dashboard
- **Plotly**: Interactive visualizations
- **Pandas**: Data manipulation
- **Requests**: API communication

## 🛠️ Troubleshooting

### Issue: Models not loading
**Solution**: Make sure to run `train_model.py` first to generate model files

### Issue: API connection error
**Solution**: Ensure Flask API is running on port 5000

### Issue: Dataset not found
**Solution**: Run `generate_demo_data.py` to create the dataset

### Issue: Import errors
**Solution**: Activate virtual environment and install dependencies:
```bash
venv\Scripts\activate
pip install -r requirements.txt
```

## 📝 Sample Batch CSV Format

```csv
PM2.5,PM10,CO,NO2,SO2,O3,Temperature,Humidity
45.0,60.0,0.5,30.0,20.0,50.0,25.0,60.0
85.0,120.0,1.2,45.0,30.0,70.0,28.0,65.0
35.0,50.0,0.3,25.0,15.0,45.0,22.0,55.0
```

## 🚀 Advanced Usage

### Custom Dataset
Replace `dataset/air_quality.csv` with your own data maintaining the same column structure.

### Model Tuning
Edit hyperparameters in `backend/model/train_model.py`:
```python
model = DecisionTreeRegressor(
    max_depth=6,           # Increase for more complex models
    min_samples_split=20,  # Adjust for regularization
    random_state=42
)
```

### API Integration
Use the REST API in your own applications:
```python
import requests

response = requests.post('http://127.0.0.1:5000/predict', json={
    "PM2.5": 50.0, "PM10": 60.0, "CO": 0.5,
    "NO2": 30.0, "SO2": 20.0, "O3": 50.0,
    "Temperature": 25.0, "Humidity": 60.0
})

result = response.json()
print(f"AQI: {result['AQI']}, Category: {result['Category']}")
```

## 📧 Support

For issues or questions, please check:
1. Run `test_api.py` to verify API connectivity
2. Check `model_evaluation.txt` for model performance
3. Ensure all dependencies are installed

## 🎉 Next Steps

1. ✅ Try different input combinations in the dashboard
2. ✅ Upload a batch CSV file for bulk predictions
3. ✅ Integrate the API into your own applications
4. ✅ Experiment with different ML models
5. ✅ Deploy to production with real air quality data

---

**Built with ❤️ for cleaner air and healthier communities**

🌱 **EcoVision** - Empowering environmental awareness through AI
