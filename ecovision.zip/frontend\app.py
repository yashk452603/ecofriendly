import streamlit as st
import requests
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Page configuration
st.set_page_config(
    page_title="EcoVision - AQI Predictor",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling
st.markdown("""
    <style>
    .main {
        background-color: #f0f8ff;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border-radius: 10px;
        font-weight: bold;
        width: 100%;
        padding: 10px;
        font-size: 16px;
    }
    .stButton>button:hover {
        background-color: #45a049;
    }
    .metric-card {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    h1 {
        color: #2c3e50;
    }
    h2 {
        color: #34495e;
    }
    h3 {
        color: #7f8c8d;
    }
    </style>
""", unsafe_allow_html=True)

# API Configuration
API_URL = "http://127.0.0.1:5000/predict"
HEALTH_API_URL = "http://127.0.0.1:5000/health"

# Title and header
st.markdown("<h1 style='text-align: center;'>🌱 EcoVision - Air Quality Prediction</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; font-size: 18px; color: #7f8c8d;'>AI-Powered Air Quality Index & Pollution Risk Prediction</p>", unsafe_allow_html=True)
st.markdown("---")

# Check API health
try:
    health_response = requests.get(HEALTH_API_URL, timeout=2)
    if health_response.status_code == 200:
        st.sidebar.success("✅ API Connected")
    else:
        st.sidebar.error("⚠️ API Unhealthy")
except:
    st.sidebar.error("❌ API Not Running")
    st.error("⚠️ Flask API is not running. Please start the backend server first!")
    st.code("cd backend\npython app.py", language="bash")
    st.stop()

# Sidebar - Input Parameters
st.sidebar.header("📊 Input Parameters")
st.sidebar.markdown("Enter pollutant measurements:")

# Input fields with tooltips and realistic ranges
pm25 = st.sidebar.slider(
    "PM2.5 (µg/m³)",
    min_value=0.0,
    max_value=200.0,
    value=50.0,
    step=1.0,
    help="Fine particulate matter (diameter ≤ 2.5 micrometers)"
)

pm10 = st.sidebar.slider(
    "PM10 (µg/m³)",
    min_value=0.0,
    max_value=300.0,
    value=60.0,
    step=1.0,
    help="Inhalable particulate matter (diameter ≤ 10 micrometers)"
)

co = st.sidebar.slider(
    "CO (mg/m³)",
    min_value=0.0,
    max_value=5.0,
    value=0.5,
    step=0.1,
    help="Carbon Monoxide concentration"
)

no2 = st.sidebar.slider(
    "NO₂ (µg/m³)",
    min_value=0.0,
    max_value=150.0,
    value=30.0,
    step=1.0,
    help="Nitrogen Dioxide concentration"
)

so2 = st.sidebar.slider(
    "SO₂ (µg/m³)",
    min_value=0.0,
    max_value=100.0,
    value=20.0,
    step=1.0,
    help="Sulfur Dioxide concentration"
)

o3 = st.sidebar.slider(
    "O₃ (µg/m³)",
    min_value=0.0,
    max_value=200.0,
    value=50.0,
    step=1.0,
    help="Ozone concentration"
)

temperature = st.sidebar.slider(
    "Temperature (°C)",
    min_value=-10.0,
    max_value=50.0,
    value=25.0,
    step=0.5,
    help="Ambient temperature"
)

humidity = st.sidebar.slider(
    "Humidity (%)",
    min_value=0.0,
    max_value=100.0,
    value=60.0,
    step=1.0,
    help="Relative humidity"
)

st.sidebar.markdown("---")

# Predict button
if st.sidebar.button("🔍 Predict AQI", use_container_width=True):
    # Prepare input data
    input_data = {
        "PM2.5": pm25,
        "PM10": pm10,
        "CO": co,
        "NO2": no2,
        "SO2": so2,
        "O3": o3,
        "Temperature": temperature,
        "Humidity": humidity
    }
    
    # Show loading spinner
    with st.spinner('🔄 Analyzing air quality...'):
        try:
            # Make API request
            response = requests.post(API_URL, json=input_data)
            
            if response.status_code == 200:
                result = response.json()
                
                # Store result in session state
                st.session_state['prediction'] = result
                st.session_state['input_data'] = input_data
                
                st.sidebar.success("✅ Prediction Complete!")
            else:
                st.error(f"❌ Error: {response.json().get('message', 'Unknown error')}")
                
        except Exception as e:
            st.error(f"❌ Connection error: {str(e)}")

# Display results if prediction exists
if 'prediction' in st.session_state:
    result = st.session_state['prediction']
    input_data = st.session_state['input_data']
    
    # Main area - Prediction Results
    st.header("🎯 Prediction Results")
    
    # Metrics row
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            label="Air Quality Index (AQI)",
            value=f"{result['AQI']:.1f}",
            delta=None
        )
    
    with col2:
        category = result['Category']
        category_color = {
            "Good": "🟢",
            "Moderate": "🟡",
            "Poor": "🔴"
        }
        st.metric(
            label="Category",
            value=f"{category_color.get(category, '⚪')} {category}",
            delta=None
        )
    
    with col3:
        st.metric(
            label="Confidence",
            value="95%",
            delta=None
        )
    
    st.markdown("---")
    
    # AQI Gauge Chart
    st.subheader("📊 AQI Gauge")
    
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=result['AQI'],
        domain={'x': [0, 1], 'y': [0, 1]},
        gauge={
            'axis': {'range': [None, 300], 'tickwidth': 1, 'tickcolor': "darkblue"},
            'bar': {'color': "darkblue"},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 50], 'color': '#00e400'},
                {'range': [51, 100], 'color': '#ffff00'},
                {'range': [101, 150], 'color': '#ff7e00'},
                {'range': [151, 200], 'color': '#ff0000'},
                {'range': [201, 300], 'color': '#8f3f97'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 100
            }
        },
        title={'text': "Current AQI Level", 'font': {'size': 24}}
    ))
    
    fig_gauge.update_layout(
        height=400,
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
        font={'color': "darkblue", 'family': "Arial"}
    )
    
    st.plotly_chart(fig_gauge, use_container_width=True)
    
    st.markdown("---")
    
    # Pollutant Bar Chart
    st.subheader("📊 Current Pollutant Levels vs Safe Limits")
    
    pollutants_df = pd.DataFrame({
        'Pollutant': ['PM2.5', 'PM10', 'CO', 'NO₂', 'SO₂', 'O₃'],
        'Concentration': [pm25, pm10, co*20, no2, so2, o3],  # Scale CO for visualization
        'Safe_Limit': [50, 100, 40, 40, 20, 100]
    })
    
    fig_bar = go.Figure()
    
    # Add concentration bars
    fig_bar.add_trace(go.Bar(
        name='Current Level',
        x=pollutants_df['Pollutant'],
        y=pollutants_df['Concentration'],
        marker_color='skyblue',
        text=pollutants_df['Concentration'].round(1),
        textposition='auto',
    ))
    
    # Add safe limit line
    fig_bar.add_trace(go.Scatter(
        name='Safe Limit',
        x=pollutants_df['Pollutant'],
        y=pollutants_df['Safe_Limit'],
        mode='markers+lines',
        marker=dict(color='red', size=12, symbol='diamond'),
        line=dict(color='red', width=2, dash='dash')
    ))
    
    fig_bar.update_layout(
        title="Pollutant Levels Comparison",
        xaxis_title="Pollutant",
        yaxis_title="Concentration (µg/m³)",
        height=400,
        hovermode='x unified',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    
    st.plotly_chart(fig_bar, use_container_width=True)
    
    st.markdown("---")
    
    # Health Advisory Section
    st.subheader("🏥 Health Advisory")
    
    category = result['Category']
    advisory_colors = {
        "Good": "#00e400",
        "Moderate": "#ffff00",
        "Poor": "#ff0000"
    }
    
    advisory_color = advisory_colors.get(category, "#cccccc")
    
    st.markdown(f"""
        <div style='padding: 20px; background-color: {advisory_color}; 
                    border-radius: 10px; color: black; box-shadow: 0 4px 6px rgba(0,0,0,0.1);'>
            <h3 style='margin: 0; color: black;'>{result['icon']} {category} Air Quality</h3>
            <p style='margin: 10px 0; font-size: 16px;'><strong>Health Impact:</strong> {result['health_impact']}</p>
            <p style='margin: 0; font-size: 16px;'><strong>Recommendation:</strong> {result['recommendation']}</p>
        </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Historical Trends Simulation
    st.subheader("📈 Simulated Weekly AQI Trend")
    
    # Generate mock historical data
    dates = pd.date_range(end=pd.Timestamp.now(), periods=7, freq='D')
    mock_aqi = [result['AQI'] + np.random.randint(-15, 15) for _ in range(7)]
    
    fig_trend = px.line(
        x=dates,
        y=mock_aqi,
        labels={'x': 'Date', 'y': 'AQI'},
        title='7-Day AQI Trend (Simulated)',
        markers=True
    )
    
    # Add reference lines
    fig_trend.add_hline(y=50, line_dash="dash", line_color="green", 
                        annotation_text="Good/Moderate Threshold", annotation_position="right")
    fig_trend.add_hline(y=100, line_dash="dash", line_color="orange", 
                        annotation_text="Moderate/Poor Threshold", annotation_position="right")
    
    fig_trend.update_traces(line_color='#1f77b4', line_width=3)
    fig_trend.update_layout(height=400, showlegend=False)
    
    st.plotly_chart(fig_trend, use_container_width=True)

else:
    # Show welcome message if no prediction yet
    st.info("👈 Please enter pollutant measurements in the sidebar and click **Predict AQI** to get started!")
    
    # Show example visualization
    st.subheader("📊 About EcoVision")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🌍 What is AQI?
        
        The **Air Quality Index (AQI)** is a number used to communicate how polluted the air is or how polluted it is forecast to become.
        
        **AQI Categories:**
        - 🟢 **0-50**: Good
        - 🟡 **51-100**: Moderate
        - 🟠 **101-150**: Unhealthy for Sensitive Groups
        - 🔴 **151-200**: Unhealthy
        - 🟣 **201-300**: Very Unhealthy
        - 🟤 **301+**: Hazardous
        """)
    
    with col2:
        st.markdown("""
        ### 🔬 Measured Pollutants
        
        EcoVision analyzes multiple pollutants:
        
        - **PM2.5**: Fine particles
        - **PM10**: Coarse particles
        - **CO**: Carbon Monoxide
        - **NO₂**: Nitrogen Dioxide
        - **SO₂**: Sulfur Dioxide
        - **O₃**: Ozone
        - **Temperature**: Environmental factor
        - **Humidity**: Environmental factor
        """)

# Sidebar - Batch Upload Feature
st.sidebar.markdown("---")
st.sidebar.header("📁 Batch Prediction")
st.sidebar.markdown("Upload a CSV file with multiple measurements")

uploaded_file = st.sidebar.file_uploader("Upload CSV", type=['csv'], help="CSV should contain columns: PM2.5, PM10, CO, NO2, SO2, O3, Temperature, Humidity")

if uploaded_file:
    try:
        df_batch = pd.read_csv(uploaded_file)
        st.write("📄 **Uploaded Data Preview:**")
        st.dataframe(df_batch.head(), use_container_width=True)
        
        if st.button("🔄 Process Batch Predictions"):
            results = []
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            for i, row in df_batch.iterrows():
                status_text.text(f"Processing record {i+1}/{len(df_batch)}...")
                
                input_data = {
                    "PM2.5": float(row['PM2.5']),
                    "PM10": float(row['PM10']),
                    "CO": float(row['CO']),
                    "NO2": float(row['NO2']),
                    "SO2": float(row['SO2']),
                    "O3": float(row['O3']),
                    "Temperature": float(row['Temperature']),
                    "Humidity": float(row['Humidity'])
                }
                
                response = requests.post(API_URL, json=input_data)
                if response.status_code == 200:
                    result = response.json()
                    results.append(result)
                else:
                    results.append({"AQI": None, "Category": "Error"})
                
                progress_bar.progress((i + 1) / len(df_batch))
            
            status_text.text("✅ Batch processing complete!")
            
            # Add results to dataframe
            df_batch['Predicted_AQI'] = [r.get('AQI', None) for r in results]
            df_batch['Category'] = [r.get('Category', 'Error') for r in results]
            
            st.success(f"✅ Successfully processed {len(df_batch)} records!")
            st.dataframe(df_batch, use_container_width=True)
            
            # Download results
            csv = df_batch.to_csv(index=False)
            st.download_button(
                label="📥 Download Results",
                data=csv,
                file_name=f"aqi_predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
                use_container_width=True
            )
    
    except Exception as e:
        st.error(f"❌ Error processing file: {str(e)}")

# Footer
st.markdown("---")
st.markdown("""
    <div style='text-align: center; color: #7f8c8d; padding: 20px;'>
        <p>🌱 <strong>EcoVision</strong> - AI-Powered Air Quality Prediction System</p>
        <p>Powered by Machine Learning | Built with Streamlit & Flask</p>
    </div>
""", unsafe_allow_html=True)
