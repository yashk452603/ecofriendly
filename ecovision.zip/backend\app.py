from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np
from datetime import datetime
import os

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Load models and scaler
MODEL_DIR = os.path.join(os.path.dirname(__file__), 'model')

try:
    reg_model = joblib.load(os.path.join(MODEL_DIR, 'model_reg.pkl'))
    class_model = joblib.load(os.path.join(MODEL_DIR, 'model_class.pkl'))
    scaler = joblib.load(os.path.join(MODEL_DIR, 'scaler.pkl'))
    print("✅ Models loaded successfully")
except Exception as e:
    print(f"❌ Error loading models: {str(e)}")
    print("💡 Please run 'python model/train_model.py' first to train the models")
    reg_model = None
    class_model = None
    scaler = None

# Feature names
FEATURES = ['PM2.5', 'PM10', 'CO', 'NO2', 'SO2', 'O3', 'Temperature', 'Humidity']

# Health advisory messages
HEALTH_ADVISORIES = {
    "Good": {
        "message": "Air quality is satisfactory, and air pollution poses little or no risk.",
        "recommendation": "Enjoy your normal outdoor activities.",
        "icon": "😊"
    },
    "Moderate": {
        "message": "Air quality is acceptable. However, there may be a risk for some people, particularly those who are unusually sensitive to air pollution.",
        "recommendation": "Unusually sensitive people should consider limiting prolonged outdoor exertion.",
        "icon": "😐"
    },
    "Poor": {
        "message": "Members of sensitive groups may experience health effects. The general public is less likely to be affected.",
        "recommendation": "People with respiratory or heart conditions, children and older adults should limit prolonged outdoor exertion.",
        "icon": "😷"
    }
}

@app.route('/', methods=['GET'])
def home():
    """API home endpoint"""
    return jsonify({
        "message": "🌿 EcoVision API Running",
        "version": "1.0",
        "status": "active",
        "endpoints": {
            "/": "API information",
            "/health": "Health check",
            "/predict": "AQI prediction (POST)"
        },
        "timestamp": datetime.now().isoformat()
    })

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    models_loaded = all([reg_model is not None, class_model is not None, scaler is not None])
    
    return jsonify({
        "status": "healthy" if models_loaded else "unhealthy",
        "models_loaded": models_loaded,
        "timestamp": datetime.now().isoformat()
    }), 200 if models_loaded else 503

@app.route('/predict', methods=['POST'])
def predict():
    """Predict AQI and risk category"""
    try:
        # Check if models are loaded
        if any([reg_model is None, class_model is None, scaler is None]):
            return jsonify({
                "error": "Models not loaded",
                "message": "Please train the models first by running 'python model/train_model.py'"
            }), 503
        
        # Get JSON data
        data = request.get_json()
        
        if not data:
            return jsonify({
                "error": "No data provided",
                "message": "Please provide JSON data with pollutant measurements"
            }), 400
        
        # Validate required fields
        missing_fields = [field for field in FEATURES if field not in data]
        if missing_fields:
            return jsonify({
                "error": "Missing required fields",
                "missing_fields": missing_fields,
                "required_fields": FEATURES
            }), 400
        
        # Extract features
        try:
            features = np.array([[
                float(data['PM2.5']),
                float(data['PM10']),
                float(data['CO']),
                float(data['NO2']),
                float(data['SO2']),
                float(data['O3']),
                float(data['Temperature']),
                float(data['Humidity'])
            ]])
        except ValueError as e:
            return jsonify({
                "error": "Invalid data type",
                "message": "All feature values must be numeric",
                "details": str(e)
            }), 400
        
        # Validate ranges (no negative values)
        if np.any(features < 0):
            return jsonify({
                "error": "Invalid values",
                "message": "Pollutant concentrations and environmental values cannot be negative"
            }), 400
        
        # Scale features
        features_scaled = scaler.transform(features)
        
        # Make predictions
        aqi_prediction = float(reg_model.predict(features_scaled)[0])
        category_prediction = class_model.predict(features_scaled)[0]
        
        # Get health advisory
        advisory = HEALTH_ADVISORIES.get(category_prediction, {
            "message": "Unable to determine health impact",
            "recommendation": "Please consult local air quality guidelines",
            "icon": "❓"
        })
        
        # Log prediction
        timestamp = datetime.now()
        print(f"[{timestamp.isoformat()}] Prediction - AQI: {aqi_prediction:.2f}, Category: {category_prediction}")
        
        # Prepare response
        response = {
            "AQI": round(aqi_prediction, 2),
            "Category": category_prediction,
            "health_impact": advisory["message"],
            "recommendation": advisory["recommendation"],
            "icon": advisory["icon"],
            "timestamp": timestamp.isoformat(),
            "input_data": {
                "PM2.5": float(data['PM2.5']),
                "PM10": float(data['PM10']),
                "CO": float(data['CO']),
                "NO2": float(data['NO2']),
                "SO2": float(data['SO2']),
                "O3": float(data['O3']),
                "Temperature": float(data['Temperature']),
                "Humidity": float(data['Humidity'])
            }
        }
        
        return jsonify(response), 200
    
    except Exception as e:
        print(f"❌ Error during prediction: {str(e)}")
        return jsonify({
            "error": "Internal server error",
            "message": str(e)
        }), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🌱 EcoVision Flask API Server")
    print("=" * 60)
    print(f"🚀 Starting server on http://127.0.0.1:5000")
    print(f"📡 Endpoints available:")
    print(f"   GET  / - API information")
    print(f"   GET  /health - Health check")
    print(f"   POST /predict - AQI prediction")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
