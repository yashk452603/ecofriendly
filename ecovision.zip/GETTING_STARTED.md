# 🌱 EcoVision - Getting Started Guide

## Welcome to EcoVision!

This guide will help you set up and run the **EcoVision AI-Powered Air Quality Prediction System** in just a few minutes.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start (5 Minutes)](#quick-start-5-minutes)
3. [What You'll Get](#what-youll-get)
4. [Using the Dashboard](#using-the-dashboard)
5. [Using the API](#using-the-api)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before you begin, ensure you have:

- ✅ **Python 3.8 or higher** installed
- ✅ **pip** package manager
- ✅ **Internet connection** (for installing packages)

**Check your Python version:**
```bash
python --version
```

If Python is not installed, download it from [python.org](https://www.python.org/downloads/)

---

## Quick Start (5 Minutes)

### Step 1: Install Dependencies (1 minute)

Open Command Prompt or PowerShell in the `ecovision` folder and run:

```bash
python -m pip install -r requirements.txt
```

**Or use the automated setup:**
```bash
setup.bat
```

### Step 2: Generate Dataset (30 seconds)

```bash
cd dataset
python generate_demo_data.py
cd ..
```

**Expected output:**
```
✅ Demo dataset created: air_quality.csv
📊 Total records: 1000
```

### Step 3: Train Models (1 minute)

```bash
cd backend\model
python train_model.py
cd ..\..
```

**Expected output:**
```
✅ Regression Model - R² Score: 0.87, RMSE: 15.3
✅ Classification Model - Accuracy: 92%
✅ All models and reports saved successfully
```

### Step 4: Start API Server (Keep Running)

**Open Terminal 1:**
```bash
cd backend
python app.py
```

**You should see:**
```
🌱 EcoVision Flask API Server
🚀 Starting server on http://127.0.0.1:5000
```

**Keep this terminal open!**

### Step 5: Start Dashboard

**Open Terminal 2 (new window):**
```bash
streamlit run frontend\app.py
```

**Browser will automatically open** at `http://localhost:8501`

If not, manually visit: **http://localhost:8501**

---

## What You'll Get

### 🎯 Dashboard Features

1. **Interactive Input Panel**
   - Adjust 8 pollutant parameters using sliders
   - Real-time validation
   - Clear units and tooltips

2. **Beautiful Visualizations**
   - AQI Gauge Chart (color-coded)
   - Pollutant Bar Chart
   - Weekly Trend Chart
   - Health Advisory Cards

3. **Batch Processing**
   - Upload CSV files
   - Process multiple predictions
   - Download results

### 🌐 API Endpoints

- `GET /` - API information
- `GET /health` - Health check
- `POST /predict` - AQI prediction

---

## Using the Dashboard

### Making a Single Prediction

1. **Adjust the sliders** in the left sidebar:
   - PM2.5 (Fine particles)
   - PM10 (Coarse particles)
   - CO (Carbon Monoxide)
   - NO₂ (Nitrogen Dioxide)
   - SO₂ (Sulfur Dioxide)
   - O₃ (Ozone)
   - Temperature
   - Humidity

2. **Click "🔍 Predict AQI"**

3. **View your results:**
   - AQI Value
   - Category (Good/Moderate/Poor)
   - Health Advisory
   - Interactive Charts

### Batch Predictions

1. **Prepare a CSV file** with these columns:
   ```
   PM2.5,PM10,CO,NO2,SO2,O3,Temperature,Humidity
   ```

2. **Use the sample file** `sample_batch.csv` as a template

3. **In the sidebar:**
   - Click "📁 Batch Prediction"
   - Upload your CSV
   - Click "🔄 Process Batch Predictions"

4. **Download results** using the download button

---

## Using the API

### Test the API

Run the test script:
```bash
python test_api.py
```

### Example API Request (Python)

```python
import requests

response = requests.post('http://127.0.0.1:5000/predict', json={
    "PM2.5": 85.0,
    "PM10": 120.0,
    "CO": 1.2,
    "NO2": 45.0,
    "SO2": 30.0,
    "O3": 70.0,
    "Temperature": 28.0,
    "Humidity": 65.0
})

result = response.json()
print(f"AQI: {result['AQI']}")
print(f"Category: {result['Category']}")
print(f"Health Impact: {result['health_impact']}")
```

### Example API Request (cURL)

```bash
curl -X POST http://127.0.0.1:5000/predict \
  -H "Content-Type: application/json" \
  -d "{\"PM2.5\": 85.0, \"PM10\": 120.0, \"CO\": 1.2, \"NO2\": 45.0, \"SO2\": 30.0, \"O3\": 70.0, \"Temperature\": 28.0, \"Humidity\": 65.0}"
```

### API Response

```json
{
  "AQI": 128.45,
  "Category": "Poor",
  "health_impact": "Members of sensitive groups may experience health effects...",
  "recommendation": "People with respiratory conditions should limit outdoor activities...",
  "icon": "😷",
  "timestamp": "2025-11-05T10:30:00",
  "input_data": { ... }
}
```

---

## Troubleshooting

### "No module named 'flask'" or similar

**Solution:**
```bash
python -m pip install flask flask-cors streamlit pandas numpy scikit-learn plotly joblib requests matplotlib
```

### "Models not found" error

**Solution:**
```bash
cd backend\model
python train_model.py
cd ..\..
```

### "API not running" in dashboard

**Solution:**
Make sure Terminal 1 with the Flask API is still running

### Port already in use

**For API (Port 5000):**
- Close other applications using port 5000
- Or edit `backend/app.py` and change the port number

**For Dashboard (Port 8501):**
```bash
streamlit run frontend\app.py --server.port 8502
```

### "Dataset not found"

**Solution:**
```bash
cd dataset
python generate_demo_data.py
cd ..
```

---

## AQI Categories Reference

| AQI Range | Category | Color | Health Impact |
|-----------|----------|-------|---------------|
| 0-50 | Good | 🟢 Green | Air quality is satisfactory |
| 51-100 | Moderate | 🟡 Yellow | Acceptable for most people |
| 101-150 | Unhealthy for Sensitive | 🟠 Orange | Sensitive groups affected |
| 151-200 | Unhealthy | 🔴 Red | Everyone may experience effects |
| 201-300 | Very Unhealthy | 🟣 Purple | Health alert |
| 301+ | Hazardous | 🟤 Maroon | Emergency conditions |

---

## Next Steps

Now that you have EcoVision running:

1. ✅ **Experiment** with different input values
2. ✅ **Upload** your own CSV files for batch predictions
3. ✅ **Integrate** the API into your own applications
4. ✅ **Customize** the models and parameters
5. ✅ **Deploy** to production with real air quality data

---

## Additional Resources

- 📖 **Full Documentation:** `README.md`
- 🚀 **Quick Start:** `QUICKSTART.txt`
- 🔧 **Installation:** `INSTALLATION.txt`
- 📊 **Project Summary:** `PROJECT_SUMMARY.txt`

---

## Support

Having issues? Check these files:

1. `INSTALLATION.txt` - Detailed installation instructions
2. `QUICKSTART.txt` - Step-by-step guide
3. `README.md` - Complete documentation

---

**🎉 Congratulations! You're now ready to predict air quality with AI!**

Built with ❤️ for cleaner air and healthier communities

🌱 **EcoVision** - Empowering environmental awareness through AI
