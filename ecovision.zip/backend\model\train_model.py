import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import joblib
import matplotlib.pyplot as plt
import os

print("=" * 60)
print("🌱 EcoVision - AI Model Training Pipeline")
print("=" * 60)

# Define feature columns
FEATURES = ['PM2.5', 'PM10', 'CO', 'NO2', 'SO2', 'O3', 'Temperature', 'Humidity']

def categorize_aqi(aqi):
    """Categorize AQI into risk levels"""
    if aqi <= 50:
        return "Good"
    elif aqi <= 100:
        return "Moderate"
    else:
        return "Poor"

def load_and_preprocess_data(file_path):
    """Load and preprocess the dataset"""
    print(f"\n📂 Loading dataset from: {file_path}")
    
    try:
        df = pd.read_csv(file_path)
        print(f"✅ Dataset loaded successfully")
        print(f"📊 Shape: {df.shape}")
        
        # Check for missing values
        missing = df.isnull().sum()
        if missing.sum() > 0:
            print(f"⚠️  Missing values found:")
            print(missing[missing > 0])
            print(f"🔧 Dropping rows with missing values...")
            df = df.dropna()
        else:
            print(f"✅ No missing values found")
        
        # Verify required columns exist
        missing_cols = [col for col in FEATURES + ['AQI'] if col not in df.columns]
        if missing_cols:
            raise ValueError(f"❌ Missing required columns: {missing_cols}")
        
        print(f"✅ All required columns present")
        
        # Remove outliers using IQR method
        Q1 = df['AQI'].quantile(0.25)
        Q3 = df['AQI'].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        before_count = len(df)
        df = df[(df['AQI'] >= lower_bound) & (df['AQI'] <= upper_bound)]
        after_count = len(df)
        
        print(f"🔧 Outlier removal: {before_count - after_count} samples removed")
        print(f"📊 Final dataset size: {after_count} samples")
        
        return df
    
    except FileNotFoundError:
        print(f"❌ Error: File not found - {file_path}")
        print(f"💡 Please run 'generate_demo_data.py' first to create the dataset")
        raise
    except Exception as e:
        print(f"❌ Error loading dataset: {str(e)}")
        raise

def prepare_features(df):
    """Prepare features and targets"""
    print(f"\n🔧 Preparing features and targets...")
    
    # Features
    X = df[FEATURES].values
    
    # Regression target (numerical AQI)
    y_reg = df['AQI'].values
    
    # Classification target (AQI categories)
    df['AQI_Category'] = df['AQI'].apply(categorize_aqi)
    y_class = df['AQI_Category'].values
    
    # Category distribution
    category_counts = df['AQI_Category'].value_counts()
    print(f"\n📊 Category Distribution:")
    for category, count in category_counts.items():
        percentage = (count / len(df)) * 100
        print(f"   {category}: {count} ({percentage:.1f}%)")
    
    return X, y_reg, y_class

def train_regression_model(X_train, X_test, y_train, y_test, scaler):
    """Train and evaluate regression model"""
    print(f"\n" + "=" * 60)
    print(f"🔮 Training Regression Model (AQI Prediction)")
    print(f"=" * 60)
    
    # Scale features
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = DecisionTreeRegressor(max_depth=6, min_samples_split=20, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Predictions
    y_pred = model.predict(X_test_scaled)
    
    # Metrics
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    
    print(f"\n📊 Regression Model Performance:")
    print(f"   Mean Absolute Error (MAE): {mae:.2f}")
    print(f"   Root Mean Squared Error (RMSE): {rmse:.2f}")
    print(f"   R² Score: {r2:.4f}")
    
    # Feature importance
    feature_importance = model.feature_importances_
    print(f"\n🎯 Feature Importance:")
    for i, importance in enumerate(feature_importance):
        print(f"   {FEATURES[i]}: {importance:.4f}")
    
    return model, mae, rmse, r2, feature_importance

def train_classification_model(X_train, X_test, y_train, y_test, scaler):
    """Train and evaluate classification model"""
    print(f"\n" + "=" * 60)
    print(f"🎯 Training Classification Model (Risk Category)")
    print(f"=" * 60)
    
    # Scale features (use the same scaler fitted for regression)
    X_train_scaled = scaler.transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = DecisionTreeClassifier(max_depth=6, min_samples_split=20, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Predictions
    y_pred = model.predict(X_test_scaled)
    
    # Metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    
    print(f"\n📊 Classification Model Performance:")
    print(f"   Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   Precision: {precision:.4f}")
    print(f"   Recall: {recall:.4f}")
    print(f"   F1-Score: {f1:.4f}")
    
    print(f"\n📋 Detailed Classification Report:")
    print(classification_report(y_test, y_pred))
    
    return model, accuracy, precision, recall, f1

def save_models(reg_model, class_model, scaler, model_dir=''):
    """Save trained models and scaler"""
    print(f"\n" + "=" * 60)
    print(f"💾 Saving Models")
    print(f"=" * 60)
    
    # Save regression model
    reg_path = os.path.join(model_dir, 'model_reg.pkl')
    joblib.dump(reg_model, reg_path)
    reg_size = os.path.getsize(reg_path) / 1024
    print(f"✅ Regression model saved: {reg_path} ({reg_size:.2f} KB)")
    
    # Save classification model
    class_path = os.path.join(model_dir, 'model_class.pkl')
    joblib.dump(class_model, class_path)
    class_size = os.path.getsize(class_path) / 1024
    print(f"✅ Classification model saved: {class_path} ({class_size:.2f} KB)")
    
    # Save scaler
    scaler_path = os.path.join(model_dir, 'scaler.pkl')
    joblib.dump(scaler, scaler_path)
    scaler_size = os.path.getsize(scaler_path) / 1024
    print(f"✅ Scaler saved: {scaler_path} ({scaler_size:.2f} KB)")

def save_evaluation_report(mae, rmse, r2, accuracy, precision, recall, f1, model_dir=''):
    """Save evaluation metrics to file"""
    report_path = os.path.join(model_dir, 'model_evaluation.txt')
    
    with open(report_path, 'w') as f:
        f.write("=" * 60 + "\n")
        f.write("🌱 EcoVision - Model Evaluation Report\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("📊 REGRESSION MODEL (AQI Prediction)\n")
        f.write("-" * 60 + "\n")
        f.write(f"Mean Absolute Error (MAE): {mae:.2f}\n")
        f.write(f"Root Mean Squared Error (RMSE): {rmse:.2f}\n")
        f.write(f"R² Score: {r2:.4f}\n\n")
        
        f.write("🎯 CLASSIFICATION MODEL (Risk Category)\n")
        f.write("-" * 60 + "\n")
        f.write(f"Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall: {recall:.4f}\n")
        f.write(f"F1-Score: {f1:.4f}\n")
    
    print(f"✅ Evaluation report saved: {report_path}")

def plot_feature_importance(feature_importance, model_dir=''):
    """Plot and save feature importance"""
    sorted_idx = np.argsort(feature_importance)[::-1]
    
    plt.figure(figsize=(10, 6))
    plt.bar(range(len(FEATURES)), feature_importance[sorted_idx], color='skyblue')
    plt.xticks(range(len(FEATURES)), [FEATURES[i] for i in sorted_idx], rotation=45)
    plt.xlabel('Features')
    plt.ylabel('Importance')
    plt.title('Feature Importance for AQI Prediction')
    plt.tight_layout()
    
    plot_path = os.path.join(model_dir, 'feature_importance.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"✅ Feature importance plot saved: {plot_path}")

def main():
    # File paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(os.path.dirname(script_dir))
    dataset_path = os.path.join(project_root, 'dataset', 'air_quality.csv')
    model_dir = script_dir
    
    # Load and preprocess data
    df = load_and_preprocess_data(dataset_path)
    
    # Prepare features
    X, y_reg, y_class = prepare_features(df)
    
    # Split data
    print(f"\n🔧 Splitting data (80% train, 20% test)...")
    X_train, X_test, y_reg_train, y_reg_test, y_class_train, y_class_test = train_test_split(
        X, y_reg, y_class, test_size=0.2, random_state=42
    )
    print(f"✅ Training samples: {len(X_train)}, Test samples: {len(X_test)}")
    
    # Initialize scaler
    scaler = StandardScaler()
    
    # Train regression model
    reg_model, mae, rmse, r2, feature_importance = train_regression_model(
        X_train, X_test, y_reg_train, y_reg_test, scaler
    )
    
    # Train classification model
    class_model, accuracy, precision, recall, f1 = train_classification_model(
        X_train, X_test, y_class_train, y_class_test, scaler
    )
    
    # Save models
    save_models(reg_model, class_model, scaler, model_dir)
    
    # Save evaluation report
    save_evaluation_report(mae, rmse, r2, accuracy, precision, recall, f1, model_dir)
    
    # Plot feature importance
    plot_feature_importance(feature_importance, model_dir)
    
    # Final summary
    print(f"\n" + "=" * 60)
    print(f"🎉 Model Training Complete!")
    print(f"=" * 60)
    print(f"✅ Regression Model - R² Score: {r2:.2f}, RMSE: {rmse:.2f}")
    print(f"✅ Classification Model - Accuracy: {accuracy*100:.0f}%")
    print(f"✅ All models and reports saved successfully")
    print(f"\n💡 Next step: Run the Flask API (backend/app.py)")

if __name__ == "__main__":
    main()
