import pandas as pd
import numpy as np

np.random.seed(42)
n_samples = 1000

print("🔄 Generating demo air quality dataset...")

data = {
    'PM2.5': np.random.uniform(10, 200, n_samples),
    'PM10': np.random.uniform(20, 300, n_samples),
    'CO': np.random.uniform(0.1, 5.0, n_samples),
    'NO2': np.random.uniform(10, 150, n_samples),
    'SO2': np.random.uniform(5, 100, n_samples),
    'O3': np.random.uniform(20, 200, n_samples),
    'Temperature': np.random.uniform(15, 40, n_samples),
    'Humidity': np.random.uniform(30, 90, n_samples),
}

# Generate realistic AQI based on pollutants
data['AQI'] = (
    data['PM2.5'] * 0.5 + 
    data['PM10'] * 0.3 + 
    data['CO'] * 10 + 
    data['NO2'] * 0.4 + 
    data['SO2'] * 0.3 + 
    data['O3'] * 0.2 +
    np.random.normal(0, 10, n_samples)
).clip(0, 500)

df = pd.DataFrame(data)
df.to_csv('air_quality.csv', index=False)

print(f"✅ Demo dataset created: air_quality.csv")
print(f"📊 Total records: {len(df)}")
print(f"📈 AQI Range: {df['AQI'].min():.1f} - {df['AQI'].max():.1f}")
print(f"\n🔍 First 5 rows:")
print(df.head())
